from django.shortcuts import render, redirect
from .forms import CSRForm
from .models import Certificate
import os
import subprocess
from django.conf import settings

def upload_csr(request):
    if request.method == 'POST':
        form = CSRForm(request.POST, request.FILES)
        if form.is_valid():
            cert_obj = form.save()
            csr_path = cert_obj.csr.path
            cert_filename = f"{cert_obj.name}.crt.pem"
            cert_path = os.path.join(settings.MEDIA_ROOT, 'issued', cert_filename)

            subprocess.run([
                "openssl", "ca",
                "-config", "/absolute/path/to/openssl.cnf",
                "-in", csr_path,
                "-out", cert_path,
                "-batch", "-notext"
            ], check=True)

            cert_obj.certificate.name = f'issued/{cert_filename}'
            cert_obj.save()

            return redirect('certs')
    else:
        form = CSRForm()
    return render(request, 'upload.html', {'form': form})

def list_certs(request):
    certs = Certificate.objects.all()
    return render(request, 'certs.html', {'certs': certs})
