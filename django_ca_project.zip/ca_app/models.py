from django.db import models

class Certificate(models.Model):
    name = models.CharField(max_length=100)
    csr = models.FileField(upload_to='csr/')
    certificate = models.FileField(upload_to='issued/', blank=True, null=True)
    issued_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
